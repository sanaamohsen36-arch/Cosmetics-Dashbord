import type {
  AdsPlatform,
  AdsRawFile,
  AdsRow,
  AppData,
  PlatformSetting,
  SalesByPlatform,
  SalesBySalesperson,
  SalesRawFile,
  UploadMode
} from "../types";
import { isSupabaseConfigured, supabase } from "./supabase";

const STORAGE_KEY = "daily-report-dashboard-v1";

const defaultPlatforms = [
  "ريجينكس",
  "ريجينكس eg",
  "واتس اب ريجينكس",
  "إجمالي السوشيال",
  "تليفون إعلان",
  "تيم المتابعة",
  "المتابعة"
];

export const createId = () => crypto.randomUUID?.() ?? `${Date.now()}-${Math.random()}`;

export const emptyData = (): AppData => ({
  salesRawFiles: [],
  salesBySalesperson: [],
  salesByPlatform: [],
  adsRawFiles: [],
  metaAds: [],
  tiktokAds: [],
  platformSettings: defaultPlatforms.map((platformName) => ({
    id: createId(),
    platformName,
    isActive: true,
    createdAt: new Date().toISOString()
  }))
});

export const getStorageMode = () => (isSupabaseConfigured ? "Supabase" : "Local fallback");

const mergeDefaultPlatforms = (settings: PlatformSetting[] = []) => {
  const seen = new Set(settings.map((item) => item.platformName.trim().toLowerCase()));
  const missing = defaultPlatforms
    .filter((platformName) => !seen.has(platformName.trim().toLowerCase()))
    .map((platformName) => ({
      id: createId(),
      platformName,
      isActive: true,
      createdAt: new Date().toISOString()
    }));
  return [...settings, ...missing];
};

export const loadData = async (): Promise<AppData> => {
  if (!supabase) return loadLocalData();

  await ensureDefaultPlatforms();
  const [
    salesRawFiles,
    salesBySalesperson,
    salesByPlatform,
    adsRawFiles,
    metaAds,
    tiktokAds,
    platformSettings
  ] = await Promise.all([
    selectAll("sales_raw_files"),
    selectAll("sales_by_salesperson"),
    selectAll("sales_by_platform"),
    selectAll("ads_raw_files"),
    selectAll("meta_ads"),
    selectAll("tiktok_ads"),
    selectAll("platform_settings")
  ]);

  return {
    salesRawFiles: salesRawFiles.map(fromSalesRawFile),
    salesBySalesperson: salesBySalesperson.map(fromSalesperson),
    salesByPlatform: salesByPlatform.map(fromPlatformSales),
    adsRawFiles: adsRawFiles.map(fromAdsRawFile),
    metaAds: metaAds.map((row) => fromAdsRow(row, "Meta")),
    tiktokAds: tiktokAds.map((row) => fromAdsRow(row, "TikTok")),
    platformSettings: mergeDefaultPlatforms(platformSettings.map(fromPlatformSetting))
  };
};

export const saveData = async (data: AppData) => {
  if (!supabase) {
    saveLocalData(data);
    return;
  }

  await deleteAllTables();
  await insertRows("platform_settings", data.platformSettings.map(toPlatformSettingRow));
  await insertRows("sales_raw_files", data.salesRawFiles.map(toSalesRawFileRow));
  await insertRows("sales_by_salesperson", data.salesBySalesperson.map(toSalespersonRow));
  await insertRows("sales_by_platform", data.salesByPlatform.map(toPlatformSalesRow));
  await insertRows("ads_raw_files", data.adsRawFiles.map(toAdsRawFileRow));
  await insertRows("meta_ads", data.metaAds.map(toMetaAdsRow));
  await insertRows("tiktok_ads", data.tiktokAds.map(toTikTokAdsRow));
};

export const subscribeToDataChanges = (onChange: () => void) => {
  if (!supabase) return () => undefined;

  const channel = supabase
    .channel("dashboard-db-changes")
    .on("postgres_changes", { event: "*", schema: "public", table: "sales_raw_files" }, onChange)
    .on("postgres_changes", { event: "*", schema: "public", table: "sales_by_salesperson" }, onChange)
    .on("postgres_changes", { event: "*", schema: "public", table: "sales_by_platform" }, onChange)
    .on("postgres_changes", { event: "*", schema: "public", table: "ads_raw_files" }, onChange)
    .on("postgres_changes", { event: "*", schema: "public", table: "meta_ads" }, onChange)
    .on("postgres_changes", { event: "*", schema: "public", table: "tiktok_ads" }, onChange)
    .on("postgres_changes", { event: "*", schema: "public", table: "platform_settings" }, onChange)
    .subscribe();

  return () => {
    void supabase.removeChannel(channel);
  };
};

const loadLocalData = (): AppData => {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return emptyData();
    const parsed = JSON.parse(raw) as AppData;
    return {
      ...emptyData(),
      ...parsed,
      adsRawFiles: (parsed.adsRawFiles ?? []).map((file) => ({
        ...file,
        salesPlatformName: file.salesPlatformName || "غير محدد"
      })),
      metaAds: (parsed.metaAds ?? []).map((row) => ({ ...row, salesPlatformName: row.salesPlatformName || "غير محدد" })),
      tiktokAds: (parsed.tiktokAds ?? []).map((row) => ({ ...row, salesPlatformName: row.salesPlatformName || "غير محدد" })),
      platformSettings: mergeDefaultPlatforms(
        parsed.platformSettings?.length ? parsed.platformSettings : emptyData().platformSettings
      )
    };
  } catch {
    return emptyData();
  }
};

const saveLocalData = (data: AppData) => {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
  window.dispatchEvent(new CustomEvent("dashboard-data-updated"));
};

const selectAll = async (table: string) => {
  if (!supabase) return [];
  const { data, error } = await supabase.from(table).select("*");
  if (error) throw error;
  return data ?? [];
};

const insertRows = async (table: string, rows: Record<string, unknown>[]) => {
  if (!supabase || rows.length === 0) return;
  const { error } = await supabase.from(table).insert(rows);
  if (error) throw error;
};

const deleteWhere = async (table: string, filters: (query: any) => any) => {
  if (!supabase) return;
  const { error } = await filters(supabase.from(table).delete());
  if (error) throw error;
};

const deleteAll = async (table: string) => {
  if (!supabase) return;
  const { error } = await supabase.from(table).delete().not("id", "is", null);
  if (error) throw error;
};

const deleteAllTables = async () => {
  await deleteAll("meta_ads");
  await deleteAll("tiktok_ads");
  await deleteAll("ads_raw_files");
  await deleteAll("sales_by_platform");
  await deleteAll("sales_by_salesperson");
  await deleteAll("sales_raw_files");
  await deleteAll("platform_settings");
};

const ensureDefaultPlatforms = async () => {
  if (!supabase) return;
  const { data, error } = await supabase.from("platform_settings").select("*");
  if (error) throw error;
  const existing = mergeDefaultPlatforms((data ?? []).map(fromPlatformSetting));
  const missing = existing.filter((item) => !(data ?? []).some((row) => row.platform_name === item.platformName));
  await insertRows("platform_settings", missing.map(toPlatformSettingRow));
};

const fillMissingPlatforms = (
  rows: SalesByPlatform[],
  reportDate: string,
  sourceFileId: string,
  settings: PlatformSetting[]
) => {
  const existing = new Set(rows.map((row) => row.platformName.trim().toLowerCase()));
  const now = new Date().toISOString();
  const zeroRows = settings
    .filter((item) => item.isActive && !existing.has(item.platformName.trim().toLowerCase()))
    .map((item) => ({
      id: createId(),
      reportDate,
      platformName: item.platformName,
      morningOrders: 0,
      morningRevenue: 0,
      eveningOrders: 0,
      eveningRevenue: 0,
      totalOrders: 0,
      totalRevenue: 0,
      sourceFileId,
      createdAt: now
    }));
  return [...rows, ...zeroRows];
};

export const saveSalesUpload = async (
  current: AppData,
  rawFile: SalesRawFile,
  people: SalesBySalesperson[],
  platforms: SalesByPlatform[],
  mode: UploadMode
): Promise<AppData> => {
  if (mode === "cancel") return current;
  const completePlatforms = fillMissingPlatforms(platforms, rawFile.reportDate, rawFile.id, current.platformSettings);
  const withoutDate =
    mode === "replace"
      ? {
          ...current,
          salesRawFiles: current.salesRawFiles.filter((file) => file.reportDate !== rawFile.reportDate),
          salesBySalesperson: current.salesBySalesperson.filter((row) => row.reportDate !== rawFile.reportDate),
          salesByPlatform: current.salesByPlatform.filter((row) => row.reportDate !== rawFile.reportDate)
        }
      : current;

  const next = {
    ...withoutDate,
    salesRawFiles: [...withoutDate.salesRawFiles, rawFile],
    salesBySalesperson: [...withoutDate.salesBySalesperson, ...people],
    salesByPlatform: [...withoutDate.salesByPlatform, ...completePlatforms]
  };

  if (!supabase) {
    saveLocalData(next);
    return next;
  }

  if (mode === "replace") {
    await deleteWhere("sales_raw_files", (query) => query.eq("report_date", rawFile.reportDate));
    await deleteWhere("sales_by_salesperson", (query) => query.eq("report_date", rawFile.reportDate));
    await deleteWhere("sales_by_platform", (query) => query.eq("report_date", rawFile.reportDate));
  }
  await insertRows("sales_raw_files", [toSalesRawFileRow(rawFile)]);
  await insertRows("sales_by_salesperson", people.map(toSalespersonRow));
  await insertRows("sales_by_platform", completePlatforms.map(toPlatformSalesRow));
  return next;
};

export const saveAdsUpload = async (
  current: AppData,
  rawFile: AdsRawFile,
  rows: AdsRow[],
  platform: AdsPlatform,
  mode: UploadMode
): Promise<AppData> => {
  if (mode === "cancel") return current;
  const tableKey = platform === "Meta" ? "metaAds" : "tiktokAds";
  const withoutDate =
    mode === "replace"
      ? {
          ...current,
          adsRawFiles: current.adsRawFiles.filter(
            (file) =>
              !(
                file.reportDate === rawFile.reportDate &&
                file.adsPlatform === platform &&
                file.salesPlatformName === rawFile.salesPlatformName
              )
          ),
          [tableKey]: current[tableKey].filter(
            (row) => !(row.reportDate === rawFile.reportDate && row.salesPlatformName === rawFile.salesPlatformName)
          )
        }
      : current;

  const next = {
    ...withoutDate,
    adsRawFiles: [...withoutDate.adsRawFiles, rawFile],
    [tableKey]: [...withoutDate[tableKey], ...rows]
  };

  if (!supabase) {
    saveLocalData(next);
    return next;
  }

  if (mode === "replace") {
    await deleteWhere("ads_raw_files", (query) =>
      query
        .eq("report_date", rawFile.reportDate)
        .eq("ads_platform", platform)
        .eq("sales_platform_name", rawFile.salesPlatformName)
    );
    await deleteWhere(platform === "Meta" ? "meta_ads" : "tiktok_ads", (query) =>
      query.eq("report_date", rawFile.reportDate).eq("sales_platform_name", rawFile.salesPlatformName)
    );
  }

  await insertRows("ads_raw_files", [toAdsRawFileRow(rawFile)]);
  await insertRows(platform === "Meta" ? "meta_ads" : "tiktok_ads", rows.map(platform === "Meta" ? toMetaAdsRow : toTikTokAdsRow));
  return next;
};

const fromSalesRawFile = (row: any): SalesRawFile => ({
  id: row.id,
  fileName: row.file_name,
  filePath: row.file_url,
  uploadedAt: row.uploaded_at,
  reportDate: row.report_date,
  ocrStatus: row.ocr_status,
  createdAt: row.created_at
});

const toSalesRawFileRow = (row: SalesRawFile) => ({
  id: row.id,
  file_name: row.fileName,
  file_url: row.filePath,
  uploaded_at: row.uploadedAt,
  report_date: row.reportDate,
  ocr_status: row.ocrStatus,
  created_at: row.createdAt
});

const fromSalesperson = (row: any): SalesBySalesperson => ({
  id: row.id,
  reportDate: row.report_date,
  salespersonName: row.salesperson_name,
  salespersonCode: row.salesperson_code,
  morningOrders: Number(row.morning_orders) || 0,
  morningRevenue: Number(row.morning_revenue) || 0,
  eveningOrders: Number(row.evening_orders) || 0,
  eveningRevenue: Number(row.evening_revenue) || 0,
  totalOrders: Number(row.total_orders) || 0,
  totalRevenue: Number(row.total_revenue) || 0,
  sourceFileId: row.source_file_id,
  createdAt: row.created_at
});

const toSalespersonRow = (row: SalesBySalesperson) => ({
  id: row.id,
  report_date: row.reportDate,
  salesperson_name: row.salespersonName,
  salesperson_code: row.salespersonCode,
  morning_orders: row.morningOrders,
  morning_revenue: row.morningRevenue,
  evening_orders: row.eveningOrders,
  evening_revenue: row.eveningRevenue,
  total_orders: row.totalOrders,
  total_revenue: row.totalRevenue,
  source_file_id: row.sourceFileId,
  created_at: row.createdAt
});

const fromPlatformSales = (row: any): SalesByPlatform => ({
  id: row.id,
  reportDate: row.report_date,
  platformName: row.platform_name,
  morningOrders: Number(row.morning_orders) || 0,
  morningRevenue: Number(row.morning_revenue) || 0,
  eveningOrders: Number(row.evening_orders) || 0,
  eveningRevenue: Number(row.evening_revenue) || 0,
  totalOrders: Number(row.total_orders) || 0,
  totalRevenue: Number(row.total_revenue) || 0,
  sourceFileId: row.source_file_id,
  createdAt: row.created_at
});

const toPlatformSalesRow = (row: SalesByPlatform) => ({
  id: row.id,
  report_date: row.reportDate,
  platform_name: row.platformName,
  morning_orders: row.morningOrders,
  morning_revenue: row.morningRevenue,
  evening_orders: row.eveningOrders,
  evening_revenue: row.eveningRevenue,
  total_orders: row.totalOrders,
  total_revenue: row.totalRevenue,
  source_file_id: row.sourceFileId,
  created_at: row.createdAt
});

const fromAdsRawFile = (row: any): AdsRawFile => ({
  id: row.id,
  fileName: row.file_name,
  filePath: row.file_url,
  uploadedAt: row.uploaded_at,
  reportDate: row.report_date,
  adsPlatform: row.ads_platform,
  salesPlatformName: row.sales_platform_name || "غير محدد",
  parsingStatus: row.parsing_status,
  createdAt: row.created_at
});

const toAdsRawFileRow = (row: AdsRawFile) => ({
  id: row.id,
  file_name: row.fileName,
  file_url: row.filePath,
  uploaded_at: row.uploadedAt,
  report_date: row.reportDate,
  ads_platform: row.adsPlatform,
  sales_platform_name: row.salesPlatformName,
  parsing_status: row.parsingStatus,
  created_at: row.createdAt
});

const fromAdsRow = (row: any, adsPlatform: AdsPlatform): AdsRow => ({
  id: row.id,
  reportDate: row.report_date,
  adsPlatform,
  salesPlatformName: row.sales_platform_name || "غير محدد",
  campaignName: row.campaign_name,
  adsetName: row.adset_name ?? row.adgroup_name ?? "",
  adName: row.ad_name,
  spend: Number(row.spend) || 0,
  impressions: Number(row.impressions) || 0,
  reach: Number(row.reach) || 0,
  clicks: Number(row.clicks) || 0,
  ctr: Number(row.ctr) || 0,
  cpc: Number(row.cpc) || 0,
  cpm: Number(row.cpm) || 0,
  leads: Number(row.leads ?? row.conversions) || 0,
  purchases: Number(row.purchases ?? row.conversions) || 0,
  purchaseValue: Number(row.purchase_value ?? row.revenue) || 0,
  sourceFileId: row.source_file_id,
  createdAt: row.created_at
});

const toMetaAdsRow = (row: AdsRow) => ({
  id: row.id,
  report_date: row.reportDate,
  sales_platform_name: row.salesPlatformName,
  campaign_name: row.campaignName,
  adset_name: row.adsetName,
  ad_name: row.adName,
  spend: row.spend,
  impressions: row.impressions,
  reach: row.reach,
  clicks: row.clicks,
  ctr: row.ctr,
  cpc: row.cpc,
  cpm: row.cpm,
  leads: row.leads,
  purchases: row.purchases,
  purchase_value: row.purchaseValue,
  source_file_id: row.sourceFileId,
  created_at: row.createdAt
});

const toTikTokAdsRow = (row: AdsRow) => ({
  id: row.id,
  report_date: row.reportDate,
  sales_platform_name: row.salesPlatformName,
  campaign_name: row.campaignName,
  adgroup_name: row.adsetName,
  ad_name: row.adName,
  spend: row.spend,
  impressions: row.impressions,
  clicks: row.clicks,
  ctr: row.ctr,
  cpc: row.cpc,
  cpm: row.cpm,
  conversions: row.purchases,
  cost_per_conversion: row.purchases ? row.spend / row.purchases : 0,
  revenue: row.purchaseValue,
  source_file_id: row.sourceFileId,
  created_at: row.createdAt
});

const fromPlatformSetting = (row: any): PlatformSetting => ({
  id: row.id,
  platformName: row.platform_name,
  isActive: Boolean(row.is_active),
  createdAt: row.created_at
});

const toPlatformSettingRow = (row: PlatformSetting) => ({
  id: row.id,
  platform_name: row.platformName,
  is_active: row.isActive,
  created_at: row.createdAt
});
